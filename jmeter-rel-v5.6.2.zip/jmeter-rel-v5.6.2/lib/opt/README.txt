lib/opt
=======

This directory is included in the Ant build classpath, 
and is used for optional jars that may be needed to build JMeter,
but which are not included in the distribution.

For example: Doccheck and svnant.